package Model.Physics;

import java.io.Serializable;

public enum BlockType implements Serializable {SIMPLE,COIN,COINS,EMPTY,QUESTION,SLIME}
