package Model.Physics;

public class Floor extends PhysicalObject {
    // Constructor
    public Floor(int[] coordinates, int height, int width) {
        super(coordinates, height, width);
    }
}
