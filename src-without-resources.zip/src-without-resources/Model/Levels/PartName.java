package Model.Levels;

public enum PartName {L1P1,L1P2,L1P3}
