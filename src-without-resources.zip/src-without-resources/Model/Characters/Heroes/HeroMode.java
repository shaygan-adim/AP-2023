package Model.Characters.Heroes;

import java.io.Serializable;

public enum HeroMode implements Serializable {MINI , MEGA , FIRE}
