package Model.Characters.Heroes;

import java.io.Serializable;

public enum HeroName implements Serializable { MARIO , LUIGI , PRINCESS , YOSHI , TOAD}
