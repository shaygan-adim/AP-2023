package Model.Shots;

public class Nuke extends Shot {
    // Constructor
    public Nuke(int x) {
        super(new int[]{x,0}, 145, 95, 0);
    }
}
