package Model.Items;

import Model.Items.Item;

public class Flower extends Item {

    // Constructor
    public Flower(double[] coordinates){
        super(coordinates,44,44);
        super.setVisible(true);
    }

}
